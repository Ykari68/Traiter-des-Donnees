#fonction recherche_dichotomique_recursive(tableau A, début, fin, x) :
    #si début <= fin :
        #milieu = (début + fin) / 2
        #si A[milieu] == x :
            #retourner milieu
        #sinon si A[milieu] > x :
            #retourner recherche_dichotomique_recursive(A, début, milieu - 1, x)
        #sinon :
            #retourner recherche_dichotomique_recursive(A, milieu + 1, fin, x)
    #sinon :
        #retourner -1
    
def binary_search_recursive(A, start, end, x):
    if start <= end:
        middle = (start + end) // 2
        if A[middle] == x:
            return middle
        elif A[middle] > x:
            return binary_search_recursive(A, start, middle - 1, x)
        else:
            return binary_search_recursive(A, middle + 1, end, x)
    else:
        return -1

sequence = [1,2,3,4,5,6,7,8,9]
x = 5
index = binary_search_recursive(sequence, 0, len(sequence) - 1, x)
print(index)


