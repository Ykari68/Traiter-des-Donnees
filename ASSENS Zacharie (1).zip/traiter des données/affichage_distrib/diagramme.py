import matplotlib.pyplot as plt
from histogramme import calculate_histogram

def display_histogram(numbers):
    histogram = calculate_histogram(numbers)

    # Récupération des numéros et fréquences pour les utiliser dans le diagramme
    x = list(histogram.keys())
    y = list(histogram.values())

    # Affichage du diagramme en bâtons
    plt.bar(x, y)
    plt.xlabel('Numéros')
    plt.ylabel('Fréquence d\'apparition')
    plt.title('Histogramme des numéros sortis')
    plt.show()


