def calculate_histogram(numbers):
    histogram = {}
    for num in numbers:
        if num not in histogram:
            histogram[num] = 1
        else:
            histogram[num] += 1
    return histogram

