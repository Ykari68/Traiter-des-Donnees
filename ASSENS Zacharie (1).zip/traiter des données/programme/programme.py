import numpy as np
import csv
import matplotlib.pyplot as plt
from histogramme import calculate_histogram

def tirage_loto(graine=123):
    if graine:
        np.random.seed(graine)

    tirage = np.random.randint(1, 46, 5)
    return tirage
def insertion_sort(A):
    for i in range(1, len(A)):
        key = A[i]
        j = i - 1
        while j >= 0 and A[j] > key:
            A[j + 1] = A[j]
            j -= 1
        A[j + 1] = key
    return A
def save_csv_data(numbers, filename):
    with open(filename, 'w') as f:
        writer = csv.writer(f)
        writer.writerow(numbers)
def load_csv_data(filename):
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            numbers = row
    return numbers
def display_histogram(numbers):
    histogram = calculate_histogram(numbers)
    x = list(histogram.keys())
    y = list(histogram.values())
    plt.bar(x, y)
    plt.xlabel('Numéros')
    plt.ylabel('Fréquence d\'apparition')
    plt.title('Histogramme des numéros sortis')
    plt.show()




tirage1 = tirage_loto()
print("Tirage 1:", tirage1)

tirage2 = tirage_loto(graine=np.random.get_state()[1][0])
print("Tirage 2:", tirage2)

tirage3 = tirage_loto(graine=np.random.get_state()[1][0])
print("Tirage 3:", tirage3)

tirages = []
tirages.append(tirage_loto())
tirages.append(tirage_loto(graine=np.random.get_state()[1][0]))
tirages.append(tirage_loto(graine=np.random.get_state()[1][0]))


tirages = [num for sublist in tirages for num in sublist]


tirages_triees = insertion_sort(tirages)
print(tirages_triees)
save_csv_data(tirages_triees, "tirages.csv")
mean_tirages = np.mean(tirages_triees)
mean_tirages = round(mean_tirages, 2)
print("Moyenne des numéros sortis :", mean_tirages)
display_histogram(tirages_triees)











