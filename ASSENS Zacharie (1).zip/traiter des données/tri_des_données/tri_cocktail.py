#procédure tri_cocktail(tableau A) :
    #début = 0
    #fin = longueur(A) - 1
    #direction = 1
    #échangé = vrai
    #tant que échangé :
        #échangé = faux
        #pour i de début à fin - 1 selon direction :
            #si (direction = 1) et (A[i] > A[i + 1]) ou (direction = -1) et (A[i] < A[i + 1]) :
                #échanger A[i] avec A[i + 1]
                #échangé = vrai
        #si direction = 1 :
            #fin = fin - 1
        #sinon :
            #début = début + 1
        #direction = direction * -1
    #fin

def cocktail_sort(A):
    start = 0
    end = len(A) - 1
    swapped = True
    direction = 1
    while swapped:
        swapped = False
        for i in range(start, end, direction):
            if (direction == 1 and A[i] > A[i + 1]) or (direction == -1 and A[i] < A[i + 1]):
                A[i], A[i + 1] = A[i + 1], A[i]
                swapped = True
        if direction == 1:
            end -= 1
        else:
            start += 1
        direction *= -1
    return A

sequence_a_trier = [3, 1, 5, 4, 2]
sequence_triee = cocktail_sort(sequence_a_trier)
print(sequence_triee)
