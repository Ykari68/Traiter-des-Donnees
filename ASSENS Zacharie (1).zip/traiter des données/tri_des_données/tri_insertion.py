#procédure tri_insertion(tableau A) :
    #pour i de 1 à longueur(A) - 1 :
        #clé = A[i]
        #j = i - 1
        #tant que j >= 0 et A[j] > clé :
            #A[j + 1] = A[j]
            #j = j - 1
        #A[j + 1] = clé
    #fin

def insertion_sort(A):
    for i in range(1, len(A)):
        key = A[i]
        j = i - 1
        while j >= 0 and A[j] > key:
            A[j + 1] = A[j]
            j -= 1
        A[j + 1] = key
    return A

sequence_a_trier = [3, 1, 5, 4, 2]
sequence_triee = insertion_sort(sequence_a_trier)
print(sequence_triee)

