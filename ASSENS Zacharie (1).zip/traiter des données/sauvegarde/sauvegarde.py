import pickle

def save_binary_data(numbers, filename):
    with open(filename, 'wb') as f:
        pickle.dump(numbers, f)

def load_binary_data(filename):
    with open(filename, 'rb') as f:
        numbers = pickle.load(f)
    return numbers