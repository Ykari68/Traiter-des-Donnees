import csv

def save_csv_data(numbers, filename):
    with open(filename, 'w') as f:
        writer = csv.writer(f)
        writer.writerow(numbers)


def load_csv_data(filename):
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            numbers = row
    return numbers
