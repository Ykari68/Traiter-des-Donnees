import json

def save_json_data(numbers, filename):
    with open(filename, 'w') as f:
        json.dump(numbers, f)


def load_json_data(filename):
    with open(filename, 'r') as f:
        numbers = json.load(f)
    return numbers
